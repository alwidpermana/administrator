<div class="mobile-buttons-container">
  <!-- Scrollspy Mobile Button Start -->
  <?php if ($mobile): ?>
    <a href="#" id="scrollSpyButton" class="spy-button" data-bs-toggle="dropdown">
      <i data-acorn-icon="menu-dropdown"></i>
    </a>
  <?php endif ?>
  <!-- Scrollspy Mobile Button End -->

  <!-- Scrollspy Mobile Dropdown Start -->
  <div class="dropdown-menu dropdown-menu-end" id="scrollSpyDropdown"></div>
  <!-- Scrollspy Mobile Dropdown End -->

  <!-- Menu Button Start -->
  <a href="#" id="mobileMenuButton" class="menu-button">
    <i data-acorn-icon="menu"></i>
  </a>
  <!-- Menu Button End -->
</div>