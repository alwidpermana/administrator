<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>Administrator | PT. Karya Putra Sangkurian</title>
<meta name="description" content="Recruitment PT. KPS" />
<!-- Favicon Tags Start -->
<link rel="icon" type="image/png" href="<?php echo base_url(); ?>assets/img/logo/logo-KPS.png">
<!-- Favicon Tags End -->
<!-- Font Tags Start -->
<link rel="preconnect" href="https://fonts.gstatic.com" />
<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300;400;700&display=swap" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700&display=swap" rel="stylesheet" />
<link rel="stylesheet" href="<?=base_url()?>assets/font/CS-Interface/style.css" />
<!-- Font Tags End -->
<!-- Vendor Styles Start -->
<link rel="stylesheet" href="<?=base_url()?>assets/css/vendor/bootstrap.min.css" />
<link rel="stylesheet" href="<?=base_url()?>assets/css/vendor/OverlayScrollbars.min.css" />

<link rel="stylesheet" href="<?=base_url()?>assets/css/vendor/select2.min.css" />

<link rel="stylesheet" href="<?=base_url()?>assets/css/vendor/select2-bootstrap4.min.css" />

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?=base_url()?>assets/css/vendor/bootstrap-datepicker3.standalone.min.css" />
<link rel="stylesheet" href="<?=base_url()?>assets/css/vendor/datatables.min.css" />

<link rel="stylesheet" href="<?=base_url()?>assets/css/vendor/tagify.css" />
<link rel="stylesheet" href="<?=base_url()?>assets/css/vendor/sweetalert2.min.css" />

<link rel="stylesheet" href="<?=base_url()?>assets/css/vendor/dropzone.min.css" />

<!-- Vendor Styles End -->
<!-- Template Base Styles Start -->
<link rel="stylesheet" href="<?=base_url()?>assets/css/styles.css" />
<!-- Template Base Styles End -->

<link rel="stylesheet" href="<?=base_url()?>assets/css/main.css" />
<script src="<?=base_url()?>assets/js/base/loader.js"></script>
<style type="text/css">
	
</style>