 <div class="modal fade" id="modal-pass" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelDefault" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="submitSetting">
        <div class="modal-body">
        <div class="row mt-2">
          <div class="col-12">
            <label class="form-label">Password Lama</label>
            <input type="password" name="inputPasswordLama" class="form-control">
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-12">
            <label class="form-label">Password Baru</label>
            <input type="password" name="inputPasswordBaru" class="form-control">
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-12">
            <label class="form-label">Konfirmasi Password</label>
            <input type="password" name="inputKonfirmasiPassword" class="form-control">
          </div>
        </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" id="btnUpdatePassword">Save changes</button>
      </div>  
      </form>
      
    </div>
  </div>
</div>
<footer>
  <div class="footer-content">
    <div class="container">
      <div class="row">
        <div class="col-12 col-sm-6">
          <p class="mb-0 text-muted text-medium"><script>document.write(new Date().getFullYear())</script> © Recruitment <a href="https://kps.co.id/" target="_blank">PT. Karya Putra Sangkuriang</a></p>
        </div>
        <div class="col-sm-6 d-none d-sm-block">
          <ul class="breadcrumb pt-0 pe-0 mb-0 float-end">
            <!-- <li class="breadcrumb-item mb-0 text-medium">
              <a href="https://1.envato.market/BX5oGy" target="_blank" class="btn-link">Review</a>
            </li> -->
            <li class="breadcrumb-item mb-0 text-medium">
              <label class="form-label"></label>
              <a href="javascript:;" target="_blank" class="btn-link">Support</a>
            </li>
            <li class="breadcrumb-item mb-0 text-medium">
              <a href="javascript:;" target="_blank" class="btn-link">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>